﻿@echo off
chcp 65001 >nul
setlocal

if "%~1"=="" (
  echo Использование: create-project-from-tz.cmd "C:\path\to\tz.txt" ["C:\path\to\NewProjectFolder"]
  echo.
  echo Если папка не указана, будет создано: %~dp0NewExamProject
  exit /b 1
)

set "TZ=%~1"
set "TARGET=%~2"
if "%TARGET%"=="" set "TARGET=%~dp0NewExamProject"

cd /d "%~dp0"
echo Создание/заполнение проекта: %TARGET%
dotnet run --project "ExamCoach\tools\AdaptTest\AdaptTest.csproj" -- "%TZ%" --apply --init --project-root="%TARGET%"
if errorlevel 1 exit /b 1

echo.
echo Готово. Сборка и запуск:
echo   cd /d "%TARGET%"
echo   dotnet build
echo   dotnet run

endlocal
