﻿@echo off
chcp 65001 >nul
setlocal

if "%~2"=="" (
  echo Использование: apply-existing-project.cmd "C:\path\to\tz.txt" "C:\path\to\ExistingProject"
  echo.
  echo Пример:
  echo apply-existing-project.cmd "C:\Users\User\Downloads\Telegram Desktop\Новый текстовый документ (8).txt" "C:\Users\User\Desktop\Test23"
  exit /b 1
)

set "TZ=%~1"
set "TARGET=%~2"

cd /d "%~dp0"
echo Применение ТЗ к готовому проекту: %TARGET%
dotnet run --project "ExamCoach\tools\AdaptTest\AdaptTest.csproj" -- "%TZ%" --apply --project-root="%TARGET%"
if errorlevel 1 exit /b 1

echo.
echo Готово. Сборка и запуск:
echo   cd /d "%TARGET%"
echo   dotnet build
echo   dotnet run

endlocal
