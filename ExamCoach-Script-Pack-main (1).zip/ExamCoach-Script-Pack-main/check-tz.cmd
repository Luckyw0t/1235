﻿@echo off
chcp 65001 >nul
setlocal

if "%~1"=="" (
  echo Использование: check-tz.cmd "C:\path\to\tz.txt"
  exit /b 1
)

cd /d "%~dp0"
dotnet run --project "ExamCoach\tools\AdaptTest\AdaptTest.csproj" -- "%~1"

endlocal
